const productForm = document.getElementById('productForm');
const resultBox = document.getElementById('result-box');


productForm.addEventListener('submit', async function(event) {
    event.preventDefault(); 

    const formData = new FormData(productForm);

    try {
        const submitBtn = productForm.querySelector('button');
        submitBtn.innerText = "Đang xử lý...";
        submitBtn.disabled = true;

        const response = await fetch('http://localhost:5000/api/v1/farmer/products', {
            method: 'POST',
            body: formData 
        });

        const resultData = await response.json();

        if (response.ok) {
            document.getElementById('batch-id').innerText = resultData.data.batchSerialNumber;

            const qrImageUrl = 'http://localhost:5000' + resultData.data.qrCodeImageUrl;
            document.getElementById('qr-image').src = qrImageUrl;

            resultBox.style.display = 'block';
            
            productForm.reset(); 
        } else {
            alert("Lỗi từ server: " + resultData.message);
        }

    } catch (error) {
        console.error("Lỗi kết nối:", error);
        alert("Không thể kết nối đến Backend. Hãy chắc chắn Server đang chạy!");
    } finally {
    
        const submitBtn = productForm.querySelector('button');
        submitBtn.innerText = "Tạo Lô Hàng & Sinh Mã QR";
        submitBtn.disabled = false;
    }
});